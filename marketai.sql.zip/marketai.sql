-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2017 at 04:45 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `marketai`
--

-- --------------------------------------------------------

--
-- Table structure for table `compititors`
--

CREATE TABLE `compititors` (
  `compititor_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `compititor_link` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compititors`
--

INSERT INTO `compititors` (`compititor_id`, `page_id`, `compititor_link`) VALUES
(1, 2, '406852839451237'),
(2, 2, '6047074339'),
(3, 2, '5678222299'),
(4, 2, '138905109499102'),
(5, 2, '236259044902');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `fb_page_id` bigint(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`page_id`, `fb_page_id`, `user_id`, `page_name`) VALUES
(2, 1972973459649272, 30, 'Unofficial: Cartoons');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `settings_id` int(11) NOT NULL,
  `settings_key` varchar(250) NOT NULL,
  `settings_value` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`settings_id`, `settings_key`, `settings_value`) VALUES
(1, 'smtp_user', 'demolast645@gmail.com'),
(2, 'smtp_pass', 'demo1admin'),
(3, 'smtp_host', 'ssl://smtp.googlemail.com'),
(4, 'smtp_port', '465'),
(5, 'smtp_protocol', 'smtp'),
(6, 'site_name', 'MarketAI'),
(7, 'mail', 'phpmailer');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(250) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `activation_token` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `active`, `activation_token`) VALUES
(30, 'Gaurav Tayade', 'tayadegaurav37@yahoo.in', '66ec5ca5a4f108389d26277c57d5c82ded3432b2f6e727c5f519a946c02d699a7126f692b63cfa53d81c017522f9daedba05d17d8a96d9c04e573cf76845468d1pdAqe9AyrM5mRiLkzP9AnWVAyXcHOxvBLYG+0DnyGHVGI8Gf4OtMqhnHWbIv6fvFaFPG5rPtDFEyVdwhQZM8Q==', 1, NULL),
(31, 'test@test.com', '', 'c51ebbd9264a891d4d0df4d9608770e3cb1d7150510d7a9fc513a4d1d602428f592924c899aeb8c1ee2686f534e17c37fb5a315b7011f5678a7675b140794011n2y/D/1mSHux3OgH/DRJCEVZ7I/vAzPJv/aaGYXoGKg=', 1, 'fZLpkFH0Y37GDeJ2ohtqBRQa8vIdWTO19SuC'),
(63, 'Guarav Tayade', 'taydegauravb@gmail.com', '4927a7205829054120f7ad7d4cab2af7338ed1ed7e6ea1d5035f2fcd0a3c4cc46e90eba31570867f9551e8d28c7eecbd04f9995755255e5815189f77ae696337ntPBoCQimjkwXrS2pw9F5HYbnwMcoJHBRk0QTV9kgXs=', 1, 'PAFMpWIHwe9Tb6mN8h4iqUDRvBSdjr357ZkK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `compititors`
--
ALTER TABLE `compititors`
  ADD PRIMARY KEY (`compititor_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`settings_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `compititors`
--
ALTER TABLE `compititors`
  MODIFY `compititor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `settings_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
